---
name: Feature
about: Submit a proposal for a new mypy feature
labels: "feature"
---

**Feature**

<!-- Enter a clear and concise description of your feature proposal here. -->

**Pitch**

<!-- Please explain why this feature should be implemented and how it would be used. Add examples, if applicable. -->
